package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here
        final String hello = "Привет, ";
        String world = "мир!";
        System.out.println(hello + world);

        Scanner sc = new Scanner(System.in);
        System.out.println("Здравствйте! Как вас зовут?");

        String text = sc.nextLine();

        System.out.println("Здравствуйте! " + text);
        System.out.println("Хорошего Вам дня!");
    }
}
